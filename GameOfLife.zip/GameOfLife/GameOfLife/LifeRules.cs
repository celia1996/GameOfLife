﻿using System;

namespace GameOfLife {
    public enum CellState {
        alive,
        dead,
    }
    
    public class LifeRules {
        public static CellState getNewCellState(CellState state, int aliveNeighbours) {
            if( checkIfAliveNeighborsLessThanTwo(state, aliveNeighbours) || checkIfAliveNeighborsMoreThanThree(state, aliveNeighbours)) { 
                return CellState.dead;
            }
            if (checkIfAliveNeighborsAreThree(state, aliveNeighbours)) {
                return CellState.alive;
            }
            return state;
        }
        
        public static Boolean checkIfAliveNeighborsLessThanTwo(CellState state, int aliveNeighbours) {
            return state == CellState.alive && aliveNeighbours < 2;
        }
        public static Boolean checkIfAliveNeighborsMoreThanThree(CellState state, int aliveNeighbours) {
            return state == CellState.alive && aliveNeighbours > 3;
        }
        public static Boolean checkIfAliveNeighborsAreThree(CellState state, int aliveNeighbours) {
            return state == CellState.dead && aliveNeighbours == 3;
        }
    }
}
