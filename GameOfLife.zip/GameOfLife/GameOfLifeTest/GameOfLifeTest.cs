using GameOfLife;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GameOfLifeTest {
    [TestClass]
    public class GameOfLifeTest {
        [TestMethod]
        public void AliveCellLessThanTwoLiveNeighborsDies() {
            CellState state = CellState.alive;
            int aliveNeighbors = 1;
            CellState newCellState = LifeRules.getNewCellState(state, aliveNeighbors);

            Assert.AreEqual(CellState.dead, newCellState);

        }

        [TestMethod]
        public void AliveCellMoreThanThreeNeighboursDies() {
            CellState state = CellState.alive;
            int aliveNeighbours = 4;
            CellState newCellState = LifeRules.getNewCellState(state, aliveNeighbours);

            Assert.AreEqual(CellState.dead, newCellState);
        }
        
        [TestMethod]
        public void DeadCellAndThreeNeighboursLives() {
            CellState state = CellState.dead;
            int aliveNeighbours = 3;
            CellState newCellState = LifeRules.getNewCellState(state, aliveNeighbours);

            Assert.AreEqual(CellState.alive, newCellState);
        }
        
        [TestMethod]
        public void AliveCellAndThreeNeighboursLives() {
            CellState state = CellState.alive;
            int aliveNeighbours = 3;
            CellState newCellState = LifeRules.getNewCellState(state, aliveNeighbours);

            Assert.AreEqual(CellState.alive, newCellState);
        }

        [TestMethod]
        public void AliveCellAndTwoNeighboursLives() {
            CellState state = CellState.alive;
            int aliveNeighbours = 2;
            CellState newCellState = LifeRules.getNewCellState(state, aliveNeighbours);

            Assert.AreEqual(CellState.alive, newCellState);
        }




    }
}
